import { createFileRoute } from "@tanstack/react-router";
import { FrameCubeApp } from "@/components/frame-cube-app";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <FrameCubeApp />;
}
