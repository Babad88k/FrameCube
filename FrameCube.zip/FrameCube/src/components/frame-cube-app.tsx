import {
  Box,
  Download,
  Layers,
  Pause,
  Play,
  RotateCcw,
  Upload,
} from "lucide-react";
import {
  lazy,
  Suspense,
  useCallback,
  useEffect,
  useRef,
  useState,
  type ChangeEvent,
  type DragEvent,
} from "react";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { useCube } from "@/lib/cube-store";
import { downloadSpriteSheet } from "@/lib/export-sheet";

const FrameCubeScene = lazy(() => import("@/components/frame-cube-scene"));

function formatTime(seconds: number) {
  return `${seconds.toFixed(2)}s`;
}

function PlaceholderCube() {
  return (
    <div className="placeholder-stage" aria-hidden="true">
      <div className="placeholder-cube">
        <span className="face-front" />
        <span className="face-back" />
        <span className="face-right" />
        <span className="face-left" />
        <span className="face-top" />
        <span className="face-bottom" />
      </div>
    </div>
  );
}

export function FrameCubeApp() {
  const clip = useCube((s) => s.clip);
  const status = useCube((s) => s.status);
  const loadingMessage = useCube((s) => s.loadingMessage);
  const progress = useCube((s) => s.progress);
  const error = useCube((s) => s.error);
  const playing = useCube((s) => s.playing);
  const playhead = useCube((s) => s.playhead);
  const viewMode = useCube((s) => s.viewMode);
  const spread = useCube((s) => s.spread);
  const trail = useCube((s) => s.trail);
  const showFuture = useCube((s) => s.showFuture);
  const threshold = useCube((s) => s.threshold);
  const [mounted, setMounted] = useState(false);
  const [dragOver, setDragOver] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    setMounted(true);
    useCube.getState().loadSample();
  }, []);

  useEffect(() => {
    const onKey = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      if (
        target instanceof HTMLInputElement ||
        target instanceof HTMLTextAreaElement ||
        target instanceof HTMLSelectElement
      ) {
        return;
      }
      const state = useCube.getState();
      const last = (state.clip?.frames.length ?? 1) - 1;
      if (event.code === "Space") {
        event.preventDefault();
        state.togglePlay();
      } else if (event.code === "ArrowRight") {
        event.preventDefault();
        state.setPlaying(false);
        state.setPlayhead(state.playhead + 1);
      } else if (event.code === "ArrowLeft") {
        event.preventDefault();
        state.setPlaying(false);
        state.setPlayhead(state.playhead - 1);
      } else if (event.code === "Home") {
        state.setPlayhead(0);
      } else if (event.code === "End") {
        state.setPlayhead(last);
      } else if (event.code === "KeyV") {
        state.setViewMode(state.viewMode === "slices" ? "volume" : "slices");
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  const onFiles = useCallback((files: FileList | null) => {
    const file = files?.[0];
    if (!file) return;
    void useCube.getState().loadFile(file);
  }, []);

  const onInput = (event: ChangeEvent<HTMLInputElement>) => {
    onFiles(event.target.files);
    event.target.value = "";
  };

  const onDrop = (event: DragEvent) => {
    event.preventDefault();
    setDragOver(false);
    onFiles(event.dataTransfer.files);
  };

  const frameCount = clip?.frames.length ?? 0;
  const frameLabel = frameCount
    ? `${Math.min(Math.floor(playhead) + 1, frameCount)} / ${frameCount}`
    : "—";

  return (
    <div
      className="relative isolate flex min-h-dvh flex-col overflow-hidden bg-background text-foreground"
      onDragOver={(event) => {
        event.preventDefault();
        setDragOver(true);
      }}
      onDragLeave={() => setDragOver(false)}
      onDrop={onDrop}
    >
      <input
        ref={fileRef}
        type="file"
        accept="video/mp4,video/webm,video/quicktime,video/*"
        className="sr-only"
        aria-hidden="true"
        tabIndex={-1}
        onChange={onInput}
      />

      <div className="scene-stage">
        {mounted ? (
          <Suspense fallback={<PlaceholderCube />}>
            <FrameCubeScene />
          </Suspense>
        ) : (
          <PlaceholderCube />
        )}
      </div>

      <header className="pointer-events-none absolute top-0 right-0 left-0 z-10 flex items-start justify-between gap-4 p-4 md:p-6">
        <div className="pointer-events-auto max-w-sm">
          <p className="font-display text-xl font-semibold tracking-tight text-balance md:text-2xl">
            <span className="text-muted">Frame</span> Cube
          </p>
          <p className="mt-1 hidden max-w-xs text-sm leading-snug text-pretty text-muted sm:block">
            Each frame is an X–Y slice. The next frame steps along Z — time as a
            volume.
          </p>
        </div>
        <div className="pointer-events-none hidden items-center gap-3 pt-1 text-xs font-medium tracking-wide text-muted md:flex">
          <span className="axis-chip axis-tag-x">X width</span>
          <span className="axis-chip axis-tag-y">Y height</span>
          <span className="axis-chip axis-tag-z">Z time</span>
        </div>
      </header>

      <aside className="pointer-events-none absolute top-24 left-6 z-10 hidden w-full max-w-xs md:block">
        <div className="pointer-events-auto rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
          <p className="text-xs font-medium uppercase tracking-wide text-muted">
            Clip
          </p>
          <p className="mt-1 truncate font-medium">{clip?.name ?? "Waiting"}</p>
          <dl className="mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm">
            <div>
              <dt className="text-muted">Frames</dt>
              <dd className="tabular-nums">{frameCount || "—"}</dd>
            </div>
            <div>
              <dt className="text-muted">Duration</dt>
              <dd className="tabular-nums">
                {clip ? formatTime(clip.duration) : "—"}
              </dd>
            </div>
            <div>
              <dt className="text-muted">Size</dt>
              <dd className="tabular-nums">
                {clip ? `${clip.width} × ${clip.height}` : "—"}
              </dd>
            </div>
            <div>
              <dt className="text-muted">Sample</dt>
              <dd className="tabular-nums">{clip ? `${clip.fps} fps` : "—"}</dd>
            </div>
          </dl>
          {clip?.truncated ? (
            <p className="mt-3 text-sm text-muted">Using the first 5 seconds.</p>
          ) : null}
        </div>
      </aside>

      <div className="flex-1" aria-hidden="true" />

      {status === "loading" ? (
        <div className="pointer-events-none absolute inset-0 z-20 flex items-center justify-center">
          <div className="pointer-events-auto w-[min(90vw,20rem)] rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]">
            <p className="text-sm font-medium">{loadingMessage || "Working…"}</p>
            <div className="mt-3 h-1 overflow-hidden rounded-full bg-surface-2">
              <div
                className="h-full bg-accent transition-[width] duration-150 ease-out"
                style={{ width: `${Math.max(progress, 0.06) * 100}%` }}
              />
            </div>
          </div>
        </div>
      ) : null}

      {error ? (
        <div className="relative z-20 mx-4 mb-2 rounded-xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)] md:absolute md:top-24 md:right-6 md:mx-0 md:mb-0 md:max-w-sm">
          <p>{error}</p>
        </div>
      ) : null}

      <footer className="relative z-10 border-t border-border bg-surface p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:p-4">
        <div className="mx-auto flex w-full max-w-5xl flex-col gap-2">
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex rounded-xl bg-background p-1">
              <Button
                variant={viewMode === "slices" ? "secondary" : "ghost"}
                size="sm"
                aria-pressed={viewMode === "slices"}
                onClick={() => useCube.getState().setViewMode("slices")}
              >
                <Layers />
                Slices
              </Button>
              <Button
                variant={viewMode === "volume" ? "secondary" : "ghost"}
                size="sm"
                aria-pressed={viewMode === "volume"}
                onClick={() => useCube.getState().setViewMode("volume")}
              >
                <Box />
                Volume
              </Button>
            </div>
            <label className="flex min-w-40 flex-1 items-center gap-3 px-1">
              <span className="hidden text-xs font-medium tracking-wide text-muted sm:inline">
                Spread
              </span>
              <Slider
                min={0.4}
                max={2.2}
                step={0.01}
                value={[spread]}
                onValueChange={(value) =>
                  useCube.getState().setSpread(value[0] ?? 1)
                }
                aria-label="Spread frames along time"
              />
            </label>
            {viewMode === "volume" ? (
              <label className="flex min-w-36 flex-1 items-center gap-3 px-1">
                <span className="hidden text-xs font-medium tracking-wide text-muted sm:inline">
                  Cut dark
                </span>
                <Slider
                  min={0}
                  max={0.45}
                  step={0.01}
                  value={[threshold]}
                  onValueChange={(value) =>
                    useCube.getState().setThreshold(value[0] ?? 0)
                  }
                  aria-label="Hide dark voxels"
                />
              </label>
            ) : (
              <label className="flex min-w-36 flex-1 items-center gap-3 px-1">
                <span className="hidden text-xs font-medium tracking-wide text-muted sm:inline">
                  Trail
                </span>
                <Slider
                  min={0.05}
                  max={0.35}
                  step={0.01}
                  value={[trail]}
                  onValueChange={(value) =>
                    useCube.getState().setTrail(value[0] ?? 0.14)
                  }
                  aria-label="Past-frame fade"
                />
              </label>
            )}
            <Button
              variant={showFuture ? "secondary" : "ghost"}
              size="sm"
              aria-pressed={showFuture}
              onClick={() => useCube.getState().setShowFuture(!showFuture)}
            >
              Future
            </Button>
          </div>

          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="icon"
              aria-label={playing ? "Pause" : "Play"}
              onClick={() => useCube.getState().togglePlay()}
              disabled={!clip}
            >
              {playing ? (
                <Pause />
              ) : (
                <Play className="ml-0.5" />
              )}
            </Button>
            <Button
              variant="ghost"
              size="icon"
              aria-label="Jump to first frame"
              onClick={() => {
                useCube.getState().setPlaying(false);
                useCube.getState().setPlayhead(0);
              }}
              disabled={!clip}
            >
              <RotateCcw />
            </Button>
            <Slider
              min={0}
              max={Math.max(frameCount - 1, 0)}
              step={0.01}
              value={[Math.min(playhead, Math.max(frameCount - 1, 0))]}
              onValueChange={(value) => {
                useCube.getState().setPlaying(false);
                useCube.getState().setPlayhead(value[0] ?? 0);
              }}
              aria-label="Playhead"
              disabled={!clip}
            />
            <span className="w-16 text-right text-sm tabular-nums text-muted">
              {frameLabel}
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <Button
              variant="outline"
              onClick={() => useCube.getState().loadSample()}
            >
              Load sample
            </Button>
            <Button onClick={() => fileRef.current?.click()}>
              <Upload />
              Upload clip
            </Button>
            <Button
              variant="ghost"
              disabled={!clip}
              onClick={() => {
                if (clip) downloadSpriteSheet(clip);
              }}
            >
              <Download />
              Export frames
            </Button>
            <p className="hidden text-xs text-muted md:inline">
              Max 5 seconds · drag to orbit · space to play
            </p>
          </div>
        </div>
      </footer>

      {dragOver ? (
        <div className="absolute inset-0 z-50 flex items-center justify-center bg-background/80">
          <p className="font-display text-2xl font-semibold tracking-tight">
            Drop a clip — first 5 seconds
          </p>
        </div>
      ) : null}
    </div>
  );
}
