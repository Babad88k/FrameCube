import { GizmoHelper, GizmoViewport, Html, Line, OrbitControls } from "@react-three/drei";
import { Canvas, useFrame } from "@react-three/fiber";
import { useEffect, useMemo, useRef, useState } from "react";
import * as THREE from "three";
import {
  opacityForFrame,
  SCENE,
  worldSize,
  type Clip,
  type WorldSize,
} from "@/lib/clip";
import { useCube } from "@/lib/cube-store";

function usePrefersReducedMotion() {
  const [reduced, setReduced] = useState(false);
  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    const sync = () => setReduced(mq.matches);
    sync();
    mq.addEventListener("change", sync);
    return () => mq.removeEventListener("change", sync);
  }, []);
  return reduced;
}

function PlayheadClock() {
  useFrame((_, delta) => {
    const d = Math.min(delta, 0.1);
    const state = useCube.getState();
    const clip = state.clip;
    if (!state.playing || !clip) return;
    const last = clip.frames.length - 1;
    let next = state.playhead + d * clip.fps;
    if (next >= last) {
      if (state.loop) next = 0;
      else {
        next = last;
        state.setPlaying(false);
      }
    }
    state.setPlayhead(next);
  });
  return null;
}

function imageDataToTexture(data: ImageData) {
  const canvas = document.createElement("canvas");
  canvas.width = data.width;
  canvas.height = data.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Could not create a texture surface.");
  ctx.putImageData(data, 0, 0);
  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.minFilter = THREE.LinearFilter;
  tex.magFilter = THREE.LinearFilter;
  tex.generateMipmaps = false;
  tex.needsUpdate = true;
  return tex;
}

function Slice({
  map,
  index,
  width,
  height,
  z,
}: {
  map: THREE.Texture;
  index: number;
  width: number;
  height: number;
  z: number;
}) {
  const material = useRef<THREE.MeshBasicMaterial>(null);
  useFrame(() => {
    const { playhead, trail, showFuture } = useCube.getState();
    if (material.current) {
      material.current.opacity = opacityForFrame(index, playhead, trail, showFuture);
    }
  });
  return (
    <mesh position={[0, 0, z]} renderOrder={index}>
      <planeGeometry args={[width, height]} />
      <meshBasicMaterial
        ref={material}
        map={map}
        transparent
        depthWrite={false}
        side={THREE.DoubleSide}
        opacity={0.2}
        toneMapped={false}
      />
    </mesh>
  );
}

function SliceStack({ clip, size }: { clip: Clip; size: WorldSize }) {
  const textures = useMemo(
    () => clip.frames.map((frame) => imageDataToTexture(frame)),
    [clip],
  );
  useEffect(() => {
    return () => {
      for (const tex of textures) tex.dispose();
    };
  }, [textures]);

  const n = clip.frames.length;
  return (
    <>
      {textures.map((tex, i) => (
        <Slice
          key={i}
          map={tex}
          index={i}
          width={size.width}
          height={size.height}
          z={n <= 1 ? 0 : (i / (n - 1) - 0.5) * size.depth}
        />
      ))}
    </>
  );
}

function makeVolumeMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      playhead: { value: 0 },
      trail: { value: 0.14 },
      showFuture: { value: 1 },
      threshold: { value: 0.08 },
      pointSize: { value: 3.2 },
      pixelRatio: { value: 1 },
    },
    vertexShader: `
      attribute float aFrame;
      attribute vec3 aColor;
      uniform float playhead;
      uniform float trail;
      uniform float showFuture;
      uniform float pointSize;
      uniform float pixelRatio;
      varying vec3 vColor;
      varying float vAlpha;

      float opacityFor(float frame) {
        float d = frame - playhead;
        if (abs(d) < 0.65) return 1.0;
        if (frame < playhead) {
          float dist = playhead - frame;
          return 0.14 + 0.70 * exp(-dist * trail);
        }
        if (showFuture < 0.5) return 0.028;
        return 0.10;
      }

      void main() {
        vColor = aColor;
        vAlpha = opacityFor(aFrame);
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = clamp(
          pointSize * pixelRatio * (1.55 / max(-mvPosition.z, 0.4)),
          1.0,
          14.0
        );
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
    fragmentShader: `
      uniform float threshold;
      varying vec3 vColor;
      varying float vAlpha;
      void main() {
        vec2 p = gl_PointCoord * 2.0 - 1.0;
        if (dot(p, p) > 1.0) discard;
        float lum = dot(vColor, vec3(0.2126, 0.7152, 0.0722));
        if (lum < threshold) discard;
        gl_FragColor = vec4(vColor, vAlpha);
      }
    `,
    transparent: true,
    depthWrite: false,
    vertexColors: false,
  });
}

function buildVolumeGeometry(clip: Clip, size: WorldSize) {
  const { frames, width: w, height: h } = clip;
  const n = frames.length;
  const total = n * w * h;
  const maxPoints = 180_000;
  const stride = Math.max(1, Math.ceil(Math.sqrt(total / maxPoints)));
  const xs = Math.ceil(w / stride);
  const ys = Math.ceil(h / stride);
  const count = n * xs * ys;
  const positions = new Float32Array(count * 3);
  const colors = new Float32Array(count * 3);
  const aFrame = new Float32Array(count);
  const color = new THREE.Color();

  let p = 0;
  for (let f = 0; f < n; f++) {
    const data = frames[f]!.data;
    const z = n <= 1 ? 0 : (f / (n - 1) - 0.5) * size.depth;
    for (let y = 0; y < h; y += stride) {
      for (let x = 0; x < w; x += stride) {
        const i = (y * w + x) * 4;
        color.setRGB(
          data[i]! / 255,
          data[i + 1]! / 255,
          data[i + 2]! / 255,
          THREE.SRGBColorSpace,
        );
        positions[p * 3] = (x / Math.max(w - 1, 1) - 0.5) * size.width;
        positions[p * 3 + 1] = (1 - y / Math.max(h - 1, 1) - 0.5) * size.height;
        positions[p * 3 + 2] = z;
        colors[p * 3] = color.r;
        colors[p * 3 + 1] = color.g;
        colors[p * 3 + 2] = color.b;
        aFrame[p] = f;
        p += 1;
      }
    }
  }

  const geo = new THREE.BufferGeometry();
  geo.setAttribute(
    "position",
    new THREE.BufferAttribute(positions.subarray(0, p * 3), 3),
  );
  geo.setAttribute(
    "aColor",
    new THREE.BufferAttribute(colors.subarray(0, p * 3), 3),
  );
  geo.setAttribute(
    "aFrame",
    new THREE.BufferAttribute(aFrame.subarray(0, p), 1),
  );
  geo.computeBoundingSphere();
  return { geo, stride };
}

function VolumeCloud({ clip, size }: { clip: Clip; size: WorldSize }) {
  const packed = useMemo(() => buildVolumeGeometry(clip, size), [clip, size]);
  const material = useMemo(() => makeVolumeMaterial(), []);

  useEffect(() => {
    material.uniforms.pointSize!.value = 2.15 * packed.stride;
  }, [material, packed.stride]);

  useEffect(() => {
    return () => {
      packed.geo.dispose();
      material.dispose();
    };
  }, [packed, material]);

  useFrame(({ gl }) => {
    const state = useCube.getState();
    material.uniforms.playhead!.value = state.playhead;
    material.uniforms.trail!.value = state.trail;
    material.uniforms.showFuture!.value = state.showFuture ? 1 : 0;
    material.uniforms.threshold!.value = state.threshold;
    material.uniforms.pixelRatio!.value = Math.min(gl.getPixelRatio(), 2);
  });

  return (
    <points
      geometry={packed.geo}
      material={material}
      frustumCulled={false}
    />
  );
}

function PlayheadMarker({ clip, size }: { clip: Clip; size: WorldSize }) {
  const ref = useRef<THREE.Group>(null);
  const n = clip.frames.length;
  useFrame(() => {
    if (!ref.current || n <= 1) return;
    const { playhead } = useCube.getState();
    ref.current.position.z = (playhead / (n - 1) - 0.5) * size.depth;
  });
  const hw = size.width / 2;
  const hh = size.height / 2;
  const points: [number, number, number][] = [
    [-hw, -hh, 0],
    [hw, -hh, 0],
    [hw, hh, 0],
    [-hw, hh, 0],
    [-hw, -hh, 0],
  ];
  return (
    <group ref={ref}>
      <mesh renderOrder={999}>
        <planeGeometry args={[size.width * 1.01, size.height * 1.01]} />
        <meshBasicMaterial
          color={SCENE.playhead}
          transparent
          opacity={0.1}
          depthWrite={false}
          side={THREE.DoubleSide}
          toneMapped={false}
        />
      </mesh>
      <Line points={points} color={SCENE.playhead} lineWidth={1.2} />
    </group>
  );
}

function Bounds({ size }: { size: WorldSize }) {
  const hw = size.width / 2;
  const hh = size.height / 2;
  const hd = size.depth / 2;
  const segments: [number, number, number][][] = [
    [[-hw, -hh, -hd], [hw, -hh, -hd]],
    [[hw, -hh, -hd], [hw, hh, -hd]],
    [[hw, hh, -hd], [-hw, hh, -hd]],
    [[-hw, hh, -hd], [-hw, -hh, -hd]],
    [[-hw, -hh, hd], [hw, -hh, hd]],
    [[hw, -hh, hd], [hw, hh, hd]],
    [[hw, hh, hd], [-hw, hh, hd]],
    [[-hw, hh, hd], [-hw, -hh, hd]],
    [[-hw, -hh, -hd], [-hw, -hh, hd]],
    [[hw, -hh, -hd], [hw, -hh, hd]],
    [[hw, hh, -hd], [hw, hh, hd]],
    [[-hw, hh, -hd], [-hw, hh, hd]],
  ];
  return (
    <group>
      {segments.map((pts, i) => (
        <Line key={i} points={pts} color={SCENE.bounds} lineWidth={1} />
      ))}
    </group>
  );
}

function AxisRig({ size }: { size: WorldSize }) {
  const ox = -size.width / 2;
  const oy = -size.height / 2;
  const oz = -size.depth / 2;
  return (
    <group>
      <Line
        points={[
          [ox, oy, oz],
          [ox + size.width, oy, oz],
        ]}
        color={SCENE.axisX}
        lineWidth={1.6}
      />
      <Line
        points={[
          [ox, oy, oz],
          [ox, oy + size.height, oz],
        ]}
        color={SCENE.axisY}
        lineWidth={1.6}
      />
      <Line
        points={[
          [ox, oy, oz],
          [ox, oy, oz + size.depth],
        ]}
        color={SCENE.axisZ}
        lineWidth={1.6}
      />
      <Html
        position={[ox + size.width + 0.12, oy, oz]}
        center
        pointerEvents="none"
      >
        <div className="axis-tag axis-tag-x max-md:hidden">X width</div>
      </Html>
      <Html
        position={[ox, oy + size.height + 0.12, oz]}
        center
        pointerEvents="none"
      >
        <div className="axis-tag axis-tag-y max-md:hidden">Y height</div>
      </Html>
      <Html
        position={[ox, oy, oz + size.depth + 0.12]}
        center
        pointerEvents="none"
      >
        <div className="axis-tag axis-tag-z max-md:hidden">Z time</div>
      </Html>
    </group>
  );
}

export default function FrameCubeScene() {
  const clip = useCube((s) => s.clip);
  const viewMode = useCube((s) => s.viewMode);
  const spread = useCube((s) => s.spread);
  const reduced = usePrefersReducedMotion();
  const [narrow, setNarrow] = useState(false);
  useEffect(() => {
    const sync = () => setNarrow(window.innerWidth < 768);
    sync();
    window.addEventListener("resize", sync);
    return () => window.removeEventListener("resize", sync);
  }, []);
  const size = clip ? worldSize(clip) : { width: 1.8, height: 1.8, depth: 1.8 };

  return (
    <Canvas
      camera={{ position: [2.05, 1.2, 2.35], fov: 40, near: 0.1, far: 40 }}
      dpr={[1, 1.75]}
      gl={{ antialias: true, alpha: false, powerPreference: "high-performance" }}
      className="touch-none"
      onCreated={({ gl }) => {
        gl.setClearColor(SCENE.background, 1);
      }}
    >
      <color attach="background" args={[SCENE.background]} />
      <PlayheadClock />
      <OrbitControls
        makeDefault
        enableDamping
        dampingFactor={0.08}
        autoRotate={!reduced}
        autoRotateSpeed={0.35}
        minDistance={1.2}
        maxDistance={9}
      />
      <group scale={[1, 1, spread]}>
        {clip && viewMode === "slices" ? (
          <SliceStack clip={clip} size={size} />
        ) : null}
        {clip && viewMode === "volume" ? (
          <VolumeCloud clip={clip} size={size} />
        ) : null}
        {clip ? <PlayheadMarker clip={clip} size={size} /> : null}
        <Bounds size={size} />
        <AxisRig size={size} />
      </group>
      {narrow ? null : (
        <GizmoHelper alignment="top-right" margin={[56, 64]}>
          <GizmoViewport
            axisColors={[SCENE.axisX, SCENE.axisY, SCENE.axisZ]}
            labelColor={SCENE.label}
          />
        </GizmoHelper>
      )}
    </Canvas>
  );
}
