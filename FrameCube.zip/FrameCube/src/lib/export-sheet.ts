import type { Clip } from "./clip";

export function downloadSpriteSheet(clip: Clip) {
  const count = clip.frames.length;
  const cols = Math.ceil(Math.sqrt(count));
  const rows = Math.ceil(count / cols);
  const canvas = document.createElement("canvas");
  canvas.width = cols * clip.width;
  canvas.height = rows * clip.height;
  const ctx = canvas.getContext("2d");
  if (!ctx) return;

  for (let i = 0; i < count; i++) {
    const x = (i % cols) * clip.width;
    const y = Math.floor(i / cols) * clip.height;
    ctx.putImageData(clip.frames[i]!, x, y);
  }

  canvas.toBlob((blob) => {
    if (!blob) return;
    const href = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = href;
    a.download = `${clip.name.replace(/\s+/g, "-").toLowerCase()}-frames.png`;
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(href), 1500);
  }, "image/png");
}
