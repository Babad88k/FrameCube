import { TARGET_FPS, type Clip } from "./clip";

const WIDTH = 128;
const HEIGHT = 72;
const DURATION = 5;
const FRAME_COUNT = TARGET_FPS * DURATION;

function drawCalibrationFrame(
  ctx: CanvasRenderingContext2D,
  w: number,
  h: number,
  t: number,
) {
  ctx.fillStyle = "#070a10";
  ctx.fillRect(0, 0, w, h);

  const cellW = w / 8;
  const cellH = h / 5;
  ctx.fillStyle = "#121a24";
  for (let gx = 0; gx < 8; gx++) {
    for (let gy = 0; gy < 5; gy++) {
      if ((gx + gy) % 2 === 0) {
        ctx.fillRect(gx * cellW, gy * cellH, cellW, cellH);
      }
    }
  }

  const scanX = t * w;
  const scanGrad = ctx.createLinearGradient(scanX - 10, 0, scanX + 10, 0);
  scanGrad.addColorStop(0, "rgba(106, 168, 181, 0)");
  scanGrad.addColorStop(0.5, "rgba(210, 230, 235, 0.85)");
  scanGrad.addColorStop(1, "rgba(106, 168, 181, 0)");
  ctx.fillStyle = scanGrad;
  ctx.fillRect(scanX - 10, 0, 20, h);

  const ringR = 6 + t * 42;
  ctx.beginPath();
  ctx.arc(w / 2, h / 2, ringR, 0, Math.PI * 2);
  ctx.strokeStyle = `rgba(106, 168, 181, ${0.85 - t * 0.45})`;
  ctx.lineWidth = 4;
  ctx.stroke();

  const x1 = w / 2 + Math.sin(t * Math.PI * 2 * 2) * w * 0.34;
  const y1 = h / 2 + Math.sin(t * Math.PI * 2 * 3) * h * 0.3;
  paintOrb(ctx, x1, y1, 14, "#f4fbff", "#7aa8b0");

  const x2 = w / 2 + Math.cos(t * Math.PI * 2 * 3) * w * 0.28;
  const y2 = h / 2 + Math.sin(t * Math.PI * 2 * 2) * h * 0.24;
  paintOrb(ctx, x2, y2, 10, "#f3efe6", "#b9a48a");

  const barW = w * t;
  ctx.fillStyle = "#d2d6dc";
  ctx.fillRect(0, h - 5, barW, 5);
}

function paintOrb(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  radius: number,
  core: string,
  mid: string,
) {
  const glow = ctx.createRadialGradient(x, y, 0, x, y, radius);
  glow.addColorStop(0, core);
  glow.addColorStop(0.35, mid);
  glow.addColorStop(1, "rgba(0, 0, 0, 0)");
  ctx.fillStyle = glow;
  ctx.beginPath();
  ctx.arc(x, y, radius, 0, Math.PI * 2);
  ctx.fill();
}

export function generateSampleClip(): Clip {
  const canvas = document.createElement("canvas");
  canvas.width = WIDTH;
  canvas.height = HEIGHT;
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) {
    throw new Error("Could not create a drawing surface for the sample clip.");
  }

  const frames: ImageData[] = [];
  for (let i = 0; i < FRAME_COUNT; i++) {
    const t = FRAME_COUNT <= 1 ? 0 : i / (FRAME_COUNT - 1);
    drawCalibrationFrame(ctx, WIDTH, HEIGHT, t);
    frames.push(ctx.getImageData(0, 0, WIDTH, HEIGHT));
  }

  return {
    name: "Calibration reel",
    width: WIDTH,
    height: HEIGHT,
    fps: TARGET_FPS,
    duration: DURATION,
    frames,
    truncated: false,
  };
}
