import { create } from "zustand";
import type { Clip } from "./clip";
import { extractFramesFromVideo } from "./extract-frames";
import { generateSampleClip } from "./sample-clip";

export type ViewMode = "slices" | "volume";
export type Status = "boot" | "loading" | "ready" | "error";

type CubeState = {
  clip: Clip | null;
  status: Status;
  loadingMessage: string;
  progress: number;
  error: string | null;
  playing: boolean;
  playhead: number;
  loop: boolean;
  viewMode: ViewMode;
  spread: number;
  trail: number;
  showFuture: boolean;
  threshold: number;
  loadSample: () => void;
  loadFile: (file: File) => Promise<void>;
  togglePlay: () => void;
  setPlaying: (playing: boolean) => void;
  setPlayhead: (playhead: number) => void;
  setViewMode: (viewMode: ViewMode) => void;
  setSpread: (spread: number) => void;
  setTrail: (trail: number) => void;
  setShowFuture: (showFuture: boolean) => void;
  setThreshold: (threshold: number) => void;
  clearError: () => void;
};

function errorMessage(err: unknown) {
  if (err instanceof Error && err.message) return err.message;
  return "Could not read that clip.";
}

export const useCube = create<CubeState>((set, get) => ({
  clip: null,
  status: "boot",
  loadingMessage: "",
  progress: 0,
  error: null,
  playing: false,
  playhead: 0,
  loop: true,
  viewMode: "slices",
  spread: 1,
  trail: 0.14,
  showFuture: true,
  threshold: 0.08,
  loadSample: () => {
    set({
      status: "loading",
      loadingMessage: "Building calibration reel…",
      progress: 0.2,
      error: null,
      playing: false,
    });
    const clip = generateSampleClip();
    set({
      clip,
      status: "ready",
      loadingMessage: "",
      progress: 1,
      playhead: 0,
      playing: true,
    });
  },
  loadFile: async (file) => {
    set({
      status: "loading",
      loadingMessage: "Reading clip…",
      progress: 0,
      error: null,
      playing: false,
    });
    try {
      const clip = await extractFramesFromVideo(file, {
        onProgress: (done, total) => {
          set({
            progress: done / total,
            loadingMessage: `Extracting frames ${done} / ${total}`,
          });
        },
      });
      set({
        clip,
        status: "ready",
        loadingMessage: "",
        progress: 1,
        playhead: 0,
        playing: true,
        error: clip.truncated
          ? "Using the first 5 seconds of that clip."
          : null,
      });
    } catch (err) {
      set({
        status: get().clip ? "ready" : "error",
        error: errorMessage(err),
        loadingMessage: "",
        playing: false,
      });
    }
  },
  togglePlay: () => set((s) => ({ playing: !s.playing })),
  setPlaying: (playing) => set({ playing }),
  setPlayhead: (playhead) => {
    const count = get().clip?.frames.length ?? 1;
    const next = Math.min(Math.max(playhead, 0), Math.max(count - 1, 0));
    set({ playhead: next });
  },
  setViewMode: (viewMode) => set({ viewMode }),
  setSpread: (spread) => set({ spread }),
  setTrail: (trail) => set({ trail }),
  setShowFuture: (showFuture) => set({ showFuture }),
  setThreshold: (threshold) => set({ threshold }),
  clearError: () => set({ error: null }),
}));
