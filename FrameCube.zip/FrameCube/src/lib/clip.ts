export const MAX_CLIP_SECONDS = 5;
export const TARGET_FPS = 12;
export const TARGET_WIDTH = 128;
export const MAX_UPLOAD_BYTES = 80 * 1024 * 1024;

export type Clip = {
  name: string;
  width: number;
  height: number;
  fps: number;
  duration: number;
  frames: ImageData[];
  truncated: boolean;
};

export type WorldSize = {
  width: number;
  height: number;
  depth: number;
};

export const SCENE = {
  background: "#0b0b0d",
  axisX: "#d46a6a",
  axisY: "#6aaf7a",
  axisZ: "#6aa8b5",
  playhead: "#6aa8b5",
  bounds: "#2a2a30",
  label: "#f1f1f3",
} as const;

const CUBE_EDGE = 1.8;

export function worldSize(clip: Clip): WorldSize {
  const aspect = clip.width / Math.max(clip.height, 1);
  if (aspect >= 1) {
    return { width: CUBE_EDGE, height: CUBE_EDGE / aspect, depth: CUBE_EDGE };
  }
  return { width: CUBE_EDGE * aspect, height: CUBE_EDGE, depth: CUBE_EDGE };
}

export function opacityForFrame(
  frame: number,
  playhead: number,
  trail: number,
  showFuture: boolean,
): number {
  const delta = frame - playhead;
  if (Math.abs(delta) < 0.65) return 1;
  if (frame < playhead) {
    const dist = playhead - frame;
    return 0.14 + 0.7 * Math.exp(-dist * trail);
  }
  return showFuture ? 0.1 : 0.028;
}

export function targetFrameSize(sourceW: number, sourceH: number) {
  const maxDim = TARGET_WIDTH;
  const scale = maxDim / Math.max(sourceW, sourceH, 1);
  const width = Math.max(2, Math.round((sourceW * scale) / 2) * 2);
  const height = Math.max(2, Math.round((sourceH * scale) / 2) * 2);
  return { width, height };
}
