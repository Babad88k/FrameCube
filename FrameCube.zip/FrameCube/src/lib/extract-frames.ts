import {
  MAX_CLIP_SECONDS,
  MAX_UPLOAD_BYTES,
  TARGET_FPS,
  targetFrameSize,
  type Clip,
} from "./clip";

export type ExtractProgress = (done: number, total: number) => void;

function isVideoFile(file: File) {
  if (file.type.startsWith("video/")) return true;
  return /\.(mp4|webm|mov|m4v|ogv|ogg)$/i.test(file.name);
}

function seekTo(video: HTMLVideoElement, time: number) {
  return new Promise<void>((resolve, reject) => {
    if (Math.abs(video.currentTime - time) < 0.008) {
      resolve();
      return;
    }
    const timeout = window.setTimeout(() => {
      cleanup();
      resolve();
    }, 1600);
    const onSeeked = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error("Could not read that clip."));
    };
    const cleanup = () => {
      window.clearTimeout(timeout);
      video.removeEventListener("seeked", onSeeked);
      video.removeEventListener("error", onError);
    };
    video.addEventListener("seeked", onSeeked);
    video.addEventListener("error", onError);
    video.currentTime = time;
  });
}

function waitForMetadata(video: HTMLVideoElement) {
  if (video.readyState >= 1 && Number.isFinite(video.duration) && video.duration > 0) {
    return Promise.resolve();
  }
  return new Promise<void>((resolve, reject) => {
    const timeout = window.setTimeout(() => {
      cleanup();
      reject(new Error("That clip did not load. Try MP4 or WebM."));
    }, 12000);
    const onLoaded = () => {
      cleanup();
      resolve();
    };
    const onError = () => {
      cleanup();
      reject(new Error("Could not read that clip."));
    };
    const cleanup = () => {
      window.clearTimeout(timeout);
      video.removeEventListener("loadedmetadata", onLoaded);
      video.removeEventListener("error", onError);
    };
    video.addEventListener("loadedmetadata", onLoaded);
    video.addEventListener("error", onError);
  });
}

export async function extractFramesFromVideo(
  file: File,
  options?: { onProgress?: ExtractProgress },
): Promise<Clip> {
  if (!isVideoFile(file)) {
    throw new Error("Drop a video file (MP4, WebM, or MOV).");
  }
  if (file.size > MAX_UPLOAD_BYTES) {
    throw new Error("Clip is too large. Try a shorter or smaller file.");
  }

  const url = URL.createObjectURL(file);
  const video = document.createElement("video");
  video.muted = true;
  video.playsInline = true;
  video.preload = "auto";
  video.src = url;
  video.crossOrigin = "anonymous";

  try {
    await waitForMetadata(video);
    await video.play().catch(() => undefined);
    video.pause();

    if (!Number.isFinite(video.duration) || video.duration <= 0) {
      throw new Error("That clip has no duration we can read.");
    }

    const truncated = video.duration > MAX_CLIP_SECONDS + 0.05;
    const duration = Math.min(video.duration, MAX_CLIP_SECONDS);
    const frameCount = Math.max(2, Math.round(duration * TARGET_FPS));
    const { width, height } = targetFrameSize(video.videoWidth, video.videoHeight);

    const canvas = document.createElement("canvas");
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext("2d", { willReadFrequently: true });
    if (!ctx) throw new Error("Could not create a drawing surface.");
    ctx.imageSmoothingEnabled = true;

    const frames: ImageData[] = [];
    for (let i = 0; i < frameCount; i++) {
      const t = Math.min((i / frameCount) * duration, Math.max(duration - 0.001, 0));
      await seekTo(video, t);
      ctx.drawImage(video, 0, 0, width, height);
      frames.push(ctx.getImageData(0, 0, width, height));
      options?.onProgress?.(i + 1, frameCount);
      if (i % 4 === 3) {
        await new Promise<void>((resolve) => {
          requestAnimationFrame(() => resolve());
        });
      }
    }

    const name = file.name.replace(/\.[^.]+$/, "") || "Clip";
    return {
      name,
      width,
      height,
      fps: TARGET_FPS,
      duration,
      frames,
      truncated,
    };
  } finally {
    video.pause();
    video.removeAttribute("src");
    video.load();
    URL.revokeObjectURL(url);
  }
}
