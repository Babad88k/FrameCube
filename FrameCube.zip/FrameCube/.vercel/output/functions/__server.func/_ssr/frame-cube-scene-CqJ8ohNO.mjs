import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as Html, d as CanvasTexture, f as Color, h as ShaderMaterial, i as Line, l as BufferAttribute, m as SRGBColorSpace, n as GizmoHelper, o as Canvas, p as LinearFilter, r as OrbitControls, s as useFrame, t as GizmoViewport, u as BufferGeometry } from "../_libs/@react-three/drei+[...].mjs";
import { a as worldSize, i as opacityForFrame, n as useCube, r as SCENE } from "./routes-1TfU0UhQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/frame-cube-scene-CqJ8ohNO.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function usePrefersReducedMotion() {
	const [reduced, setReduced] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
		const sync = () => setReduced(mq.matches);
		sync();
		mq.addEventListener("change", sync);
		return () => mq.removeEventListener("change", sync);
	}, []);
	return reduced;
}
function PlayheadClock() {
	useFrame((_, delta) => {
		const d = Math.min(delta, .1);
		const state = useCube.getState();
		const clip = state.clip;
		if (!state.playing || !clip) return;
		const last = clip.frames.length - 1;
		let next = state.playhead + d * clip.fps;
		if (next >= last) {
			if (state.loop) next = 0;
			else {
				next = last;
				state.setPlaying(false);
			}
		}
		state.setPlayhead(next);
	});
	return null;
}
function imageDataToTexture(data) {
	const canvas = document.createElement("canvas");
	canvas.width = data.width;
	canvas.height = data.height;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not create a texture surface.");
	ctx.putImageData(data, 0, 0);
	const tex = new CanvasTexture(canvas);
	tex.colorSpace = SRGBColorSpace;
	tex.minFilter = LinearFilter;
	tex.magFilter = LinearFilter;
	tex.generateMipmaps = false;
	tex.needsUpdate = true;
	return tex;
}
function Slice({ map, index, width, height, z }) {
	const material = (0, import_react.useRef)(null);
	useFrame(() => {
		const { playhead, trail, showFuture } = useCube.getState();
		if (material.current) material.current.opacity = opacityForFrame(index, playhead, trail, showFuture);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
		position: [
			0,
			0,
			z
		],
		renderOrder: index,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [width, height] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
			ref: material,
			map,
			transparent: true,
			depthWrite: false,
			side: 2,
			opacity: .2,
			toneMapped: false
		})]
	});
}
function SliceStack({ clip, size }) {
	const textures = (0, import_react.useMemo)(() => clip.frames.map((frame) => imageDataToTexture(frame)), [clip]);
	(0, import_react.useEffect)(() => {
		return () => {
			for (const tex of textures) tex.dispose();
		};
	}, [textures]);
	const n = clip.frames.length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: textures.map((tex, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slice, {
		map: tex,
		index: i,
		width: size.width,
		height: size.height,
		z: n <= 1 ? 0 : (i / (n - 1) - .5) * size.depth
	}, i)) });
}
function makeVolumeMaterial() {
	return new ShaderMaterial({
		uniforms: {
			playhead: { value: 0 },
			trail: { value: .14 },
			showFuture: { value: 1 },
			threshold: { value: .08 },
			pointSize: { value: 3.2 },
			pixelRatio: { value: 1 }
		},
		vertexShader: `
      attribute float aFrame;
      attribute vec3 aColor;
      uniform float playhead;
      uniform float trail;
      uniform float showFuture;
      uniform float pointSize;
      uniform float pixelRatio;
      varying vec3 vColor;
      varying float vAlpha;

      float opacityFor(float frame) {
        float d = frame - playhead;
        if (abs(d) < 0.65) return 1.0;
        if (frame < playhead) {
          float dist = playhead - frame;
          return 0.14 + 0.70 * exp(-dist * trail);
        }
        if (showFuture < 0.5) return 0.028;
        return 0.10;
      }

      void main() {
        vColor = aColor;
        vAlpha = opacityFor(aFrame);
        vec4 mvPosition = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = clamp(
          pointSize * pixelRatio * (1.55 / max(-mvPosition.z, 0.4)),
          1.0,
          14.0
        );
        gl_Position = projectionMatrix * mvPosition;
      }
    `,
		fragmentShader: `
      uniform float threshold;
      varying vec3 vColor;
      varying float vAlpha;
      void main() {
        vec2 p = gl_PointCoord * 2.0 - 1.0;
        if (dot(p, p) > 1.0) discard;
        float lum = dot(vColor, vec3(0.2126, 0.7152, 0.0722));
        if (lum < threshold) discard;
        gl_FragColor = vec4(vColor, vAlpha);
      }
    `,
		transparent: true,
		depthWrite: false,
		vertexColors: false
	});
}
function buildVolumeGeometry(clip, size) {
	const { frames, width: w, height: h } = clip;
	const n = frames.length;
	const total = n * w * h;
	const stride = Math.max(1, Math.ceil(Math.sqrt(total / 18e4)));
	const xs = Math.ceil(w / stride);
	const ys = Math.ceil(h / stride);
	const count = n * xs * ys;
	const positions = new Float32Array(count * 3);
	const colors = new Float32Array(count * 3);
	const aFrame = new Float32Array(count);
	const color = new Color();
	let p = 0;
	for (let f = 0; f < n; f++) {
		const data = frames[f].data;
		const z = n <= 1 ? 0 : (f / (n - 1) - .5) * size.depth;
		for (let y = 0; y < h; y += stride) for (let x = 0; x < w; x += stride) {
			const i = (y * w + x) * 4;
			color.setRGB(data[i] / 255, data[i + 1] / 255, data[i + 2] / 255, SRGBColorSpace);
			positions[p * 3] = (x / Math.max(w - 1, 1) - .5) * size.width;
			positions[p * 3 + 1] = (1 - y / Math.max(h - 1, 1) - .5) * size.height;
			positions[p * 3 + 2] = z;
			colors[p * 3] = color.r;
			colors[p * 3 + 1] = color.g;
			colors[p * 3 + 2] = color.b;
			aFrame[p] = f;
			p += 1;
		}
	}
	const geo = new BufferGeometry();
	geo.setAttribute("position", new BufferAttribute(positions.subarray(0, p * 3), 3));
	geo.setAttribute("aColor", new BufferAttribute(colors.subarray(0, p * 3), 3));
	geo.setAttribute("aFrame", new BufferAttribute(aFrame.subarray(0, p), 1));
	geo.computeBoundingSphere();
	return {
		geo,
		stride
	};
}
function VolumeCloud({ clip, size }) {
	const packed = (0, import_react.useMemo)(() => buildVolumeGeometry(clip, size), [clip, size]);
	const material = (0, import_react.useMemo)(() => makeVolumeMaterial(), []);
	(0, import_react.useEffect)(() => {
		material.uniforms.pointSize.value = 2.15 * packed.stride;
	}, [material, packed.stride]);
	(0, import_react.useEffect)(() => {
		return () => {
			packed.geo.dispose();
			material.dispose();
		};
	}, [packed, material]);
	useFrame(({ gl }) => {
		const state = useCube.getState();
		material.uniforms.playhead.value = state.playhead;
		material.uniforms.trail.value = state.trail;
		material.uniforms.showFuture.value = state.showFuture ? 1 : 0;
		material.uniforms.threshold.value = state.threshold;
		material.uniforms.pixelRatio.value = Math.min(gl.getPixelRatio(), 2);
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("points", {
		geometry: packed.geo,
		material,
		frustumCulled: false
	});
}
function PlayheadMarker({ clip, size }) {
	const ref = (0, import_react.useRef)(null);
	const n = clip.frames.length;
	useFrame(() => {
		if (!ref.current || n <= 1) return;
		const { playhead } = useCube.getState();
		ref.current.position.z = (playhead / (n - 1) - .5) * size.depth;
	});
	const hw = size.width / 2;
	const hh = size.height / 2;
	const points = [
		[
			-hw,
			-hh,
			0
		],
		[
			hw,
			-hh,
			0
		],
		[
			hw,
			hh,
			0
		],
		[
			-hw,
			hh,
			0
		],
		[
			-hw,
			-hh,
			0
		]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
		ref,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("mesh", {
			renderOrder: 999,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("planeGeometry", { args: [size.width * 1.01, size.height * 1.01] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("meshBasicMaterial", {
				color: SCENE.playhead,
				transparent: true,
				opacity: .1,
				depthWrite: false,
				side: 2,
				toneMapped: false
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
			points,
			color: SCENE.playhead,
			lineWidth: 1.2
		})]
	});
}
function Bounds({ size }) {
	const hw = size.width / 2;
	const hh = size.height / 2;
	const hd = size.depth / 2;
	const segments = [
		[[
			-hw,
			-hh,
			-hd
		], [
			hw,
			-hh,
			-hd
		]],
		[[
			hw,
			-hh,
			-hd
		], [
			hw,
			hh,
			-hd
		]],
		[[
			hw,
			hh,
			-hd
		], [
			-hw,
			hh,
			-hd
		]],
		[[
			-hw,
			hh,
			-hd
		], [
			-hw,
			-hh,
			-hd
		]],
		[[
			-hw,
			-hh,
			hd
		], [
			hw,
			-hh,
			hd
		]],
		[[
			hw,
			-hh,
			hd
		], [
			hw,
			hh,
			hd
		]],
		[[
			hw,
			hh,
			hd
		], [
			-hw,
			hh,
			hd
		]],
		[[
			-hw,
			hh,
			hd
		], [
			-hw,
			-hh,
			hd
		]],
		[[
			-hw,
			-hh,
			-hd
		], [
			-hw,
			-hh,
			hd
		]],
		[[
			hw,
			-hh,
			-hd
		], [
			hw,
			-hh,
			hd
		]],
		[[
			hw,
			hh,
			-hd
		], [
			hw,
			hh,
			hd
		]],
		[[
			-hw,
			hh,
			-hd
		], [
			-hw,
			hh,
			hd
		]]
	];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("group", { children: segments.map((pts, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
		points: pts,
		color: SCENE.bounds,
		lineWidth: 1
	}, i)) });
}
function AxisRig({ size }) {
	const ox = -size.width / 2;
	const oy = -size.height / 2;
	const oz = -size.depth / 2;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
			points: [[
				ox,
				oy,
				oz
			], [
				ox + size.width,
				oy,
				oz
			]],
			color: SCENE.axisX,
			lineWidth: 1.6
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
			points: [[
				ox,
				oy,
				oz
			], [
				ox,
				oy + size.height,
				oz
			]],
			color: SCENE.axisY,
			lineWidth: 1.6
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Line, {
			points: [[
				ox,
				oy,
				oz
			], [
				ox,
				oy,
				oz + size.depth
			]],
			color: SCENE.axisZ,
			lineWidth: 1.6
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
			position: [
				ox + size.width + .12,
				oy,
				oz
			],
			center: true,
			pointerEvents: "none",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "axis-tag axis-tag-x max-md:hidden",
				children: "X width"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
			position: [
				ox,
				oy + size.height + .12,
				oz
			],
			center: true,
			pointerEvents: "none",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "axis-tag axis-tag-y max-md:hidden",
				children: "Y height"
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Html, {
			position: [
				ox,
				oy,
				oz + size.depth + .12
			],
			center: true,
			pointerEvents: "none",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "axis-tag axis-tag-z max-md:hidden",
				children: "Z time"
			})
		})
	] });
}
function FrameCubeScene() {
	const clip = useCube((s) => s.clip);
	const viewMode = useCube((s) => s.viewMode);
	const spread = useCube((s) => s.spread);
	const reduced = usePrefersReducedMotion();
	const [narrow, setNarrow] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		const sync = () => setNarrow(window.innerWidth < 768);
		sync();
		window.addEventListener("resize", sync);
		return () => window.removeEventListener("resize", sync);
	}, []);
	const size = clip ? worldSize(clip) : {
		width: 1.8,
		height: 1.8,
		depth: 1.8
	};
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Canvas, {
		camera: {
			position: [
				2.05,
				1.2,
				2.35
			],
			fov: 40,
			near: .1,
			far: 40
		},
		dpr: [1, 1.75],
		gl: {
			antialias: true,
			alpha: false,
			powerPreference: "high-performance"
		},
		className: "touch-none",
		onCreated: ({ gl }) => {
			gl.setClearColor(SCENE.background, 1);
		},
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("color", {
				attach: "background",
				args: [SCENE.background]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayheadClock, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OrbitControls, {
				makeDefault: true,
				enableDamping: true,
				dampingFactor: .08,
				autoRotate: !reduced,
				autoRotateSpeed: .35,
				minDistance: 1.2,
				maxDistance: 9
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("group", {
				scale: [
					1,
					1,
					spread
				],
				children: [
					clip && viewMode === "slices" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliceStack, {
						clip,
						size
					}) : null,
					clip && viewMode === "volume" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(VolumeCloud, {
						clip,
						size
					}) : null,
					clip ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlayheadMarker, {
						clip,
						size
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bounds, { size }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AxisRig, { size })
				]
			}),
			narrow ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GizmoHelper, {
				alignment: "top-right",
				margin: [56, 64],
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GizmoViewport, {
					axisColors: [
						SCENE.axisX,
						SCENE.axisY,
						SCENE.axisZ
					],
					labelColor: SCENE.label
				})
			})
		]
	});
}
//#endregion
export { FrameCubeScene as default };
