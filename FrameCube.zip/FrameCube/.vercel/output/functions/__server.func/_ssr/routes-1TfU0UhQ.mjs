import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, r as Slot, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as create } from "../_libs/zustand.mjs";
import { a as Pause, c as Box, i as Play, o as Layers, r as RotateCcw, s as Download, t as Upload } from "../_libs/lucide-react.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-1TfU0UhQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var SCENE = {
	background: "#0b0b0d",
	axisX: "#d46a6a",
	axisY: "#6aaf7a",
	axisZ: "#6aa8b5",
	playhead: "#6aa8b5",
	bounds: "#2a2a30",
	label: "#f1f1f3"
};
var CUBE_EDGE = 1.8;
function worldSize(clip) {
	const aspect = clip.width / Math.max(clip.height, 1);
	if (aspect >= 1) return {
		width: CUBE_EDGE,
		height: CUBE_EDGE / aspect,
		depth: CUBE_EDGE
	};
	return {
		width: CUBE_EDGE * aspect,
		height: CUBE_EDGE,
		depth: CUBE_EDGE
	};
}
function opacityForFrame(frame, playhead, trail, showFuture) {
	const delta = frame - playhead;
	if (Math.abs(delta) < .65) return 1;
	if (frame < playhead) {
		const dist = playhead - frame;
		return .14 + .7 * Math.exp(-dist * trail);
	}
	return showFuture ? .1 : .028;
}
function targetFrameSize(sourceW, sourceH) {
	const scale = 128 / Math.max(sourceW, sourceH, 1);
	return {
		width: Math.max(2, Math.round(sourceW * scale / 2) * 2),
		height: Math.max(2, Math.round(sourceH * scale / 2) * 2)
	};
}
function isVideoFile(file) {
	if (file.type.startsWith("video/")) return true;
	return /\.(mp4|webm|mov|m4v|ogv|ogg)$/i.test(file.name);
}
function seekTo(video, time) {
	return new Promise((resolve, reject) => {
		if (Math.abs(video.currentTime - time) < .008) {
			resolve();
			return;
		}
		const timeout = window.setTimeout(() => {
			cleanup();
			resolve();
		}, 1600);
		const onSeeked = () => {
			cleanup();
			resolve();
		};
		const onError = () => {
			cleanup();
			reject(/* @__PURE__ */ new Error("Could not read that clip."));
		};
		const cleanup = () => {
			window.clearTimeout(timeout);
			video.removeEventListener("seeked", onSeeked);
			video.removeEventListener("error", onError);
		};
		video.addEventListener("seeked", onSeeked);
		video.addEventListener("error", onError);
		video.currentTime = time;
	});
}
function waitForMetadata(video) {
	if (video.readyState >= 1 && Number.isFinite(video.duration) && video.duration > 0) return Promise.resolve();
	return new Promise((resolve, reject) => {
		const timeout = window.setTimeout(() => {
			cleanup();
			reject(/* @__PURE__ */ new Error("That clip did not load. Try MP4 or WebM."));
		}, 12e3);
		const onLoaded = () => {
			cleanup();
			resolve();
		};
		const onError = () => {
			cleanup();
			reject(/* @__PURE__ */ new Error("Could not read that clip."));
		};
		const cleanup = () => {
			window.clearTimeout(timeout);
			video.removeEventListener("loadedmetadata", onLoaded);
			video.removeEventListener("error", onError);
		};
		video.addEventListener("loadedmetadata", onLoaded);
		video.addEventListener("error", onError);
	});
}
async function extractFramesFromVideo(file, options) {
	if (!isVideoFile(file)) throw new Error("Drop a video file (MP4, WebM, or MOV).");
	if (file.size > 83886080) throw new Error("Clip is too large. Try a shorter or smaller file.");
	const url = URL.createObjectURL(file);
	const video = document.createElement("video");
	video.muted = true;
	video.playsInline = true;
	video.preload = "auto";
	video.src = url;
	video.crossOrigin = "anonymous";
	try {
		await waitForMetadata(video);
		await video.play().catch(() => void 0);
		video.pause();
		if (!Number.isFinite(video.duration) || video.duration <= 0) throw new Error("That clip has no duration we can read.");
		const truncated = video.duration > 5.05;
		const duration = Math.min(video.duration, 5);
		const frameCount = Math.max(2, Math.round(duration * 12));
		const { width, height } = targetFrameSize(video.videoWidth, video.videoHeight);
		const canvas = document.createElement("canvas");
		canvas.width = width;
		canvas.height = height;
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) throw new Error("Could not create a drawing surface.");
		ctx.imageSmoothingEnabled = true;
		const frames = [];
		for (let i = 0; i < frameCount; i++) {
			await seekTo(video, Math.min(i / frameCount * duration, Math.max(duration - .001, 0)));
			ctx.drawImage(video, 0, 0, width, height);
			frames.push(ctx.getImageData(0, 0, width, height));
			options?.onProgress?.(i + 1, frameCount);
			if (i % 4 === 3) await new Promise((resolve) => {
				requestAnimationFrame(() => resolve());
			});
		}
		return {
			name: file.name.replace(/\.[^.]+$/, "") || "Clip",
			width,
			height,
			fps: 12,
			duration,
			frames,
			truncated
		};
	} finally {
		video.pause();
		video.removeAttribute("src");
		video.load();
		URL.revokeObjectURL(url);
	}
}
var WIDTH = 128;
var HEIGHT = 72;
var DURATION = 5;
var FRAME_COUNT = 12 * DURATION;
function drawCalibrationFrame(ctx, w, h, t) {
	ctx.fillStyle = "#070a10";
	ctx.fillRect(0, 0, w, h);
	const cellW = w / 8;
	const cellH = h / 5;
	ctx.fillStyle = "#121a24";
	for (let gx = 0; gx < 8; gx++) for (let gy = 0; gy < 5; gy++) if ((gx + gy) % 2 === 0) ctx.fillRect(gx * cellW, gy * cellH, cellW, cellH);
	const scanX = t * w;
	const scanGrad = ctx.createLinearGradient(scanX - 10, 0, scanX + 10, 0);
	scanGrad.addColorStop(0, "rgba(106, 168, 181, 0)");
	scanGrad.addColorStop(.5, "rgba(210, 230, 235, 0.85)");
	scanGrad.addColorStop(1, "rgba(106, 168, 181, 0)");
	ctx.fillStyle = scanGrad;
	ctx.fillRect(scanX - 10, 0, 20, h);
	const ringR = 6 + t * 42;
	ctx.beginPath();
	ctx.arc(w / 2, h / 2, ringR, 0, Math.PI * 2);
	ctx.strokeStyle = `rgba(106, 168, 181, ${.85 - t * .45})`;
	ctx.lineWidth = 4;
	ctx.stroke();
	paintOrb(ctx, w / 2 + Math.sin(t * Math.PI * 2 * 2) * w * .34, h / 2 + Math.sin(t * Math.PI * 2 * 3) * h * .3, 14, "#f4fbff", "#7aa8b0");
	paintOrb(ctx, w / 2 + Math.cos(t * Math.PI * 2 * 3) * w * .28, h / 2 + Math.sin(t * Math.PI * 2 * 2) * h * .24, 10, "#f3efe6", "#b9a48a");
	const barW = w * t;
	ctx.fillStyle = "#d2d6dc";
	ctx.fillRect(0, h - 5, barW, 5);
}
function paintOrb(ctx, x, y, radius, core, mid) {
	const glow = ctx.createRadialGradient(x, y, 0, x, y, radius);
	glow.addColorStop(0, core);
	glow.addColorStop(.35, mid);
	glow.addColorStop(1, "rgba(0, 0, 0, 0)");
	ctx.fillStyle = glow;
	ctx.beginPath();
	ctx.arc(x, y, radius, 0, Math.PI * 2);
	ctx.fill();
}
function generateSampleClip() {
	const canvas = document.createElement("canvas");
	canvas.width = WIDTH;
	canvas.height = HEIGHT;
	const ctx = canvas.getContext("2d", { willReadFrequently: true });
	if (!ctx) throw new Error("Could not create a drawing surface for the sample clip.");
	const frames = [];
	for (let i = 0; i < FRAME_COUNT; i++) {
		drawCalibrationFrame(ctx, WIDTH, HEIGHT, FRAME_COUNT <= 1 ? 0 : i / (FRAME_COUNT - 1));
		frames.push(ctx.getImageData(0, 0, WIDTH, HEIGHT));
	}
	return {
		name: "Calibration reel",
		width: WIDTH,
		height: HEIGHT,
		fps: 12,
		duration: DURATION,
		frames,
		truncated: false
	};
}
function errorMessage(err) {
	if (err instanceof Error && err.message) return err.message;
	return "Could not read that clip.";
}
var useCube = create((set, get) => ({
	clip: null,
	status: "boot",
	loadingMessage: "",
	progress: 0,
	error: null,
	playing: false,
	playhead: 0,
	loop: true,
	viewMode: "slices",
	spread: 1,
	trail: .14,
	showFuture: true,
	threshold: .08,
	loadSample: () => {
		set({
			status: "loading",
			loadingMessage: "Building calibration reel…",
			progress: .2,
			error: null,
			playing: false
		});
		set({
			clip: generateSampleClip(),
			status: "ready",
			loadingMessage: "",
			progress: 1,
			playhead: 0,
			playing: true
		});
	},
	loadFile: async (file) => {
		set({
			status: "loading",
			loadingMessage: "Reading clip…",
			progress: 0,
			error: null,
			playing: false
		});
		try {
			const clip = await extractFramesFromVideo(file, { onProgress: (done, total) => {
				set({
					progress: done / total,
					loadingMessage: `Extracting frames ${done} / ${total}`
				});
			} });
			set({
				clip,
				status: "ready",
				loadingMessage: "",
				progress: 1,
				playhead: 0,
				playing: true,
				error: clip.truncated ? "Using the first 5 seconds of that clip." : null
			});
		} catch (err) {
			set({
				status: get().clip ? "ready" : "error",
				error: errorMessage(err),
				loadingMessage: "",
				playing: false
			});
		}
	},
	togglePlay: () => set((s) => ({ playing: !s.playing })),
	setPlaying: (playing) => set({ playing }),
	setPlayhead: (playhead) => {
		const count = get().clip?.frames.length ?? 1;
		set({ playhead: Math.min(Math.max(playhead, 0), Math.max(count - 1, 0)) });
	},
	setViewMode: (viewMode) => set({ viewMode }),
	setSpread: (spread) => set({ spread }),
	setTrail: (trail) => set({ trail }),
	setShowFuture: (showFuture) => set({ showFuture }),
	setThreshold: (threshold) => set({ threshold }),
	clearError: () => set({ error: null })
}));
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[opacity,transform,background-color,color,box-shadow] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-40 active:not-disabled:scale-[0.96] [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0", {
	variants: {
		variant: {
			default: "bg-accent text-accent-fg hover:opacity-90",
			outline: "bg-surface text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			ghost: "bg-transparent text-foreground hover:bg-surface-2",
			secondary: "bg-surface-2 text-foreground hover:opacity-90"
		},
		size: {
			default: "h-touch min-h-touch px-4",
			sm: "h-10 min-h-10 px-3",
			icon: "size-touch min-h-touch min-w-touch"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		type: asChild ? void 0 : type,
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex h-touch w-full touch-none select-none items-center", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1 w-full grow overflow-hidden rounded-full bg-surface-2",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-accent" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full bg-accent shadow-[var(--shadow-border)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
	});
}
function downloadSpriteSheet(clip) {
	const count = clip.frames.length;
	const cols = Math.ceil(Math.sqrt(count));
	const rows = Math.ceil(count / cols);
	const canvas = document.createElement("canvas");
	canvas.width = cols * clip.width;
	canvas.height = rows * clip.height;
	const ctx = canvas.getContext("2d");
	if (!ctx) return;
	for (let i = 0; i < count; i++) {
		const x = i % cols * clip.width;
		const y = Math.floor(i / cols) * clip.height;
		ctx.putImageData(clip.frames[i], x, y);
	}
	canvas.toBlob((blob) => {
		if (!blob) return;
		const href = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = href;
		a.download = `${clip.name.replace(/\s+/g, "-").toLowerCase()}-frames.png`;
		a.click();
		window.setTimeout(() => URL.revokeObjectURL(href), 1500);
	}, "image/png");
}
var FrameCubeScene = (0, import_react.lazy)(() => import("./frame-cube-scene-CqJ8ohNO.mjs"));
function formatTime(seconds) {
	return `${seconds.toFixed(2)}s`;
}
function PlaceholderCube() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "placeholder-stage",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "placeholder-cube",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "face-front" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "face-back" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "face-right" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "face-left" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "face-top" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "face-bottom" })
			]
		})
	});
}
function FrameCubeApp() {
	const clip = useCube((s) => s.clip);
	const status = useCube((s) => s.status);
	const loadingMessage = useCube((s) => s.loadingMessage);
	const progress = useCube((s) => s.progress);
	const error = useCube((s) => s.error);
	const playing = useCube((s) => s.playing);
	const playhead = useCube((s) => s.playhead);
	const viewMode = useCube((s) => s.viewMode);
	const spread = useCube((s) => s.spread);
	const trail = useCube((s) => s.trail);
	const showFuture = useCube((s) => s.showFuture);
	const threshold = useCube((s) => s.threshold);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const fileRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		setMounted(true);
		useCube.getState().loadSample();
	}, []);
	(0, import_react.useEffect)(() => {
		const onKey = (event) => {
			const target = event.target;
			if (target instanceof HTMLInputElement || target instanceof HTMLTextAreaElement || target instanceof HTMLSelectElement) return;
			const state = useCube.getState();
			const last = (state.clip?.frames.length ?? 1) - 1;
			if (event.code === "Space") {
				event.preventDefault();
				state.togglePlay();
			} else if (event.code === "ArrowRight") {
				event.preventDefault();
				state.setPlaying(false);
				state.setPlayhead(state.playhead + 1);
			} else if (event.code === "ArrowLeft") {
				event.preventDefault();
				state.setPlaying(false);
				state.setPlayhead(state.playhead - 1);
			} else if (event.code === "Home") state.setPlayhead(0);
			else if (event.code === "End") state.setPlayhead(last);
			else if (event.code === "KeyV") state.setViewMode(state.viewMode === "slices" ? "volume" : "slices");
		};
		window.addEventListener("keydown", onKey);
		return () => window.removeEventListener("keydown", onKey);
	}, []);
	const onFiles = (0, import_react.useCallback)((files) => {
		const file = files?.[0];
		if (!file) return;
		useCube.getState().loadFile(file);
	}, []);
	const onInput = (event) => {
		onFiles(event.target.files);
		event.target.value = "";
	};
	const onDrop = (event) => {
		event.preventDefault();
		setDragOver(false);
		onFiles(event.dataTransfer.files);
	};
	const frameCount = clip?.frames.length ?? 0;
	const frameLabel = frameCount ? `${Math.min(Math.floor(playhead) + 1, frameCount)} / ${frameCount}` : "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative isolate flex min-h-dvh flex-col overflow-hidden bg-background text-foreground",
		onDragOver: (event) => {
			event.preventDefault();
			setDragOver(true);
		},
		onDragLeave: () => setDragOver(false),
		onDrop,
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: fileRef,
				type: "file",
				accept: "video/mp4,video/webm,video/quicktime,video/*",
				className: "sr-only",
				"aria-hidden": "true",
				tabIndex: -1,
				onChange: onInput
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "scene-stage",
				children: mounted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_react.Suspense, {
					fallback: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderCube, {}),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrameCubeScene, {})
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceholderCube, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "pointer-events-none absolute top-0 right-0 left-0 z-10 flex items-start justify-between gap-4 p-4 md:p-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto max-w-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-display text-xl font-semibold tracking-tight text-balance md:text-2xl",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-muted",
							children: "Frame"
						}), " Cube"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 hidden max-w-xs text-sm leading-snug text-pretty text-muted sm:block",
						children: "Each frame is an X–Y slice. The next frame steps along Z — time as a volume."
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-none hidden items-center gap-3 pt-1 text-xs font-medium tracking-wide text-muted md:flex",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "axis-chip axis-tag-x",
							children: "X width"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "axis-chip axis-tag-y",
							children: "Y height"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "axis-chip axis-tag-z",
							children: "Z time"
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
				className: "pointer-events-none absolute top-24 left-6 z-10 hidden w-full max-w-xs md:block",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Clip"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 truncate font-medium",
							children: clip?.name ?? "Waiting"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "mt-3 grid grid-cols-2 gap-x-4 gap-y-2 text-sm",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Frames"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums",
									children: frameCount || "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Duration"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums",
									children: clip ? formatTime(clip.duration) : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Size"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums",
									children: clip ? `${clip.width} × ${clip.height}` : "—"
								})] }),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
									className: "text-muted",
									children: "Sample"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
									className: "tabular-nums",
									children: clip ? `${clip.fps} fps` : "—"
								})] })
							]
						}),
						clip?.truncated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-muted",
							children: "Using the first 5 seconds."
						}) : null
					]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1",
				"aria-hidden": "true"
			}),
			status === "loading" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "pointer-events-none absolute inset-0 z-20 flex items-center justify-center",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "pointer-events-auto w-[min(90vw,20rem)] rounded-3xl bg-surface p-4 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: loadingMessage || "Working…"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-3 h-1 overflow-hidden rounded-full bg-surface-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full bg-accent transition-[width] duration-150 ease-out",
							style: { width: `${Math.max(progress, .06) * 100}%` }
						})
					})]
				})
			}) : null,
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "relative z-20 mx-4 mb-2 rounded-xl bg-surface px-4 py-3 text-sm shadow-[var(--shadow-border)] md:absolute md:top-24 md:right-6 md:mx-0 md:mb-0 md:max-w-sm",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: error })
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
				className: "relative z-10 border-t border-border bg-surface p-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] md:p-4",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex w-full max-w-5xl flex-col gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex rounded-xl bg-background p-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: viewMode === "slices" ? "secondary" : "ghost",
										size: "sm",
										"aria-pressed": viewMode === "slices",
										onClick: () => useCube.getState().setViewMode("slices"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Layers, {}), "Slices"]
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										variant: viewMode === "volume" ? "secondary" : "ghost",
										size: "sm",
										"aria-pressed": viewMode === "volume",
										onClick: () => useCube.getState().setViewMode("volume"),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Box, {}), "Volume"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-w-40 flex-1 items-center gap-3 px-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden text-xs font-medium tracking-wide text-muted sm:inline",
										children: "Spread"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
										min: .4,
										max: 2.2,
										step: .01,
										value: [spread],
										onValueChange: (value) => useCube.getState().setSpread(value[0] ?? 1),
										"aria-label": "Spread frames along time"
									})]
								}),
								viewMode === "volume" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-w-36 flex-1 items-center gap-3 px-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden text-xs font-medium tracking-wide text-muted sm:inline",
										children: "Cut dark"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
										min: 0,
										max: .45,
										step: .01,
										value: [threshold],
										onValueChange: (value) => useCube.getState().setThreshold(value[0] ?? 0),
										"aria-label": "Hide dark voxels"
									})]
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
									className: "flex min-w-36 flex-1 items-center gap-3 px-1",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "hidden text-xs font-medium tracking-wide text-muted sm:inline",
										children: "Trail"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
										min: .05,
										max: .35,
										step: .01,
										value: [trail],
										onValueChange: (value) => useCube.getState().setTrail(value[0] ?? .14),
										"aria-label": "Past-frame fade"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: showFuture ? "secondary" : "ghost",
									size: "sm",
									"aria-pressed": showFuture,
									onClick: () => useCube.getState().setShowFuture(!showFuture),
									children: "Future"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									size: "icon",
									"aria-label": playing ? "Pause" : "Play",
									onClick: () => useCube.getState().togglePlay(),
									disabled: !clip,
									children: playing ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "ml-0.5" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Jump to first frame",
									onClick: () => {
										useCube.getState().setPlaying(false);
										useCube.getState().setPlayhead(0);
									},
									disabled: !clip,
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									min: 0,
									max: Math.max(frameCount - 1, 0),
									step: .01,
									value: [Math.min(playhead, Math.max(frameCount - 1, 0))],
									onValueChange: (value) => {
										useCube.getState().setPlaying(false);
										useCube.getState().setPlayhead(value[0] ?? 0);
									},
									"aria-label": "Playhead",
									disabled: !clip
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "w-16 text-right text-sm tabular-nums text-muted",
									children: frameLabel
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-wrap items-center gap-2",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "outline",
									onClick: () => useCube.getState().loadSample(),
									children: "Load sample"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									onClick: () => fileRef.current?.click(),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), "Upload clip"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									variant: "ghost",
									disabled: !clip,
									onClick: () => {
										if (clip) downloadSpriteSheet(clip);
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Export frames"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "hidden text-xs text-muted md:inline",
									children: "Max 5 seconds · drag to orbit · space to play"
								})
							]
						})
					]
				})
			}),
			dragOver ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "absolute inset-0 z-50 flex items-center justify-center bg-background/80",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl font-semibold tracking-tight",
					children: "Drop a clip — first 5 seconds"
				})
			}) : null
		]
	});
}
var routes_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FrameCubeApp, {});
}
//#endregion
export { worldSize as a, opacityForFrame as i, useCube as n, SCENE as r, routes_exports as t };
